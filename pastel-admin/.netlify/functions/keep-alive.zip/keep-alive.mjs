
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// src/lib/supabase/config.ts
function normalizeSupabaseUrl(rawUrl) {
  const trimmedUrl = rawUrl.trim();
  const parsedUrl = new URL(trimmedUrl);
  const projectRef = parsedUrl.pathname.match(/\/(?:dashboard\/)?project\/([^/]+)/)?.[1];
  if (projectRef && (parsedUrl.hostname === "supabase.com" || parsedUrl.hostname === "app.supabase.com")) {
    return `https://${projectRef}.supabase.co`;
  }
  if (parsedUrl.hostname.endsWith(".supabase.co")) {
    return `${parsedUrl.protocol}//${parsedUrl.hostname}`;
  }
  return trimmedUrl.replace(/\/+$/, "");
}
function getSupabaseConfig() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!supabaseUrl || !supabaseAnonKey) {
    throw new Error("Supabase environment variables are not configured.");
  }
  return {
    url: normalizeSupabaseUrl(supabaseUrl),
    anonKey: supabaseAnonKey.trim()
  };
}
function isSupabaseConfigured() {
  return Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL?.trim() && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.trim());
}

// netlify/functions/keep-alive.mts
var keep_alive_default = async () => {
  if (!isSupabaseConfigured()) return new Response("Supabase is not configured.", { status: 500 });
  const { url, anonKey } = getSupabaseConfig();
  const response = await fetch(`${url}/rest/v1/services?select=id&limit=1`, {
    headers: { apikey: anonKey, Authorization: `Bearer ${anonKey}` }
  });
  return new Response(response.ok ? "ok" : "failed", { status: response.ok ? 200 : 502 });
};
var config = {
  schedule: "@daily"
};
export {
  config,
  keep_alive_default as default
};
